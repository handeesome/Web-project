<?php
$username="group26";//change username 
$password="9iQmYt"; //change password
$host="10.72.1.14";
$db_name="group26"; //change databasename

$connect = mysqli_connect($host,$username,$password,$db_name);

if(!$connect)
{
    echo "not connected<br>";
	}
else{
    echo "connected<br>";
}

?>