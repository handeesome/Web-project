<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" href="../style.css">

<head>
  <title>Select College</title>
</head>

<body>
<div class="navbardiv">
        <ul>
          <li><a id="head" class="navbar" href="../home.html">Log In</a></li>
          <li><a class="navbar" href="#">Sign Up</a></li>
          <li><a class="navbar" href="../maintenance.html">Maintenance</a></li>
          <li><a id ="tail" class="navbar" href="../imprint.html">Imprint Page</a></li>
        </ul>
    </div>
    <div class="logo">
        <img src="../img/logo.jpg" id="logo">
</div>
<div class="login">
    <h2>Select the College</h2>
<form id='selectcollege' method='POST' action='View_Bookings.php'>
        <div class="select">
                <select name="dropdowncollege" class="dropdown" >
                    <?php
                    $db = mysqli_connect("localhost", "group26", "9iQmYt", "group26");
                    $res = mysqli_query($db, "SELECT name FROM CollegeOffice;");
                    while ($row = mysqli_fetch_array($res)) {
                        echo ("<option value='" . $row['name'] . "'>" . $row['name'] . "</option>");
                    }
                    ?>
                </select>
                <p class="button"><input type="submit" id="register" value="Register" ></p>
           </div> 
        </form>
        
</div>
</body>
</html>