﻿
<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" href="../style.css">

<head>
    <title>Untitled 1</title>
</head>
<?php 
$connect = mysqli_connect('localhost','group26','9iQmYt','group26');
$college = $_POST['dropdowncollege'];
if($college == 'C3'){
    $cstatus = 'c3status';
}
if($college == 'Nordmetall'){
    $cstatus = 'nordstatus';
}
if($college == 'Krupp'){
    $cstatus = 'krpstatus';
}
if($college == 'Mercator'){
    $cstatus = 'mercstatus';
}
?>
<body>
    <div class="navbardiv">
        <ul>
            <li><a id="head" class="navbar" href="../home.html">Log In</a></li>
            <li><a class="navbar" href="#">Sign Up</a></li>
            <li><a class="navbar" href="../maintenance.html">Maintenance</a></li>
            <li><a id="tail" class="navbar" href="../imprint.html">Imprint Page</a></li>
        </ul>
    </div>
    <div class="logo">
        <img src="../img/logo.jpg" id="logo"></div>
    <div class='login'>
        <h1>Book an Item</h1>

        <form method="POST" action="addView_Bookings.php">
            <h4>Student name</h4>
            <div class="select">
                <select name="dropdownsid" id='college' class="dropdown">
                    <?php
                    $res = mysqli_query($connect, "SELECT sid,username FROM Student;");
                    while ($row = mysqli_fetch_array($res)) {
                        echo ("<option value='" . $row['sid'] . "'>" . $row['username'] . "</option>");
                    }
                    ?>
                    <label for="dropdown">Select</label>
                </select></div>
            <h4>Object name</h4>
            <div class="select">
                <select name="dropdownobjid" class="dropdown">
                    <?php

                    $res = mysqli_query($connect, "SELECT objid,name FROM Returnable WHERE objid IN(
                        SELECT objid FROM Objects WHERE $cstatus = 'Available');");
                    while ($row = mysqli_fetch_array($res)) {
                        echo ("<option value='" . $row['objid'] . "'>" . $row['name'] . "</option>");
                    }
                    ?>
                    <label for="dropdown">Select</label>
                    </select</div> <br> <p class="button"><input type="submit" id="register" value="Register"></p>
        </form>

    </div>

</body>

</html>