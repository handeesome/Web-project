<?php

include "config.php";
// Create the sid using uniqid(), creates random hex value
$sid = uniqid ("" ,  FALSE);
$username = mysqli_real_escape_string($connect, $_POST['username']);
$email = mysqli_real_escape_string($connect, $_POST["email"]);
$password = mysqli_real_escape_string($connect, $_POST["password"]);

//Creating the query that should be executed
$sql = "INSERT INTO Student (sid, username, email, password) values ('$sid', '$username', '$email', '$password');";


// Check connection
if ($connect->connect_error) {
  die("Connection failed: " . $connect->connect_error);
}

// Submits the query and checks whether it worked or not
if ($connect->query($sql) === TRUE) {
    echo "$sql \n";
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $connect->error;
}
//closes connection
$connect->close();
?>