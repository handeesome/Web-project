<?php
include 'config.php';
$sid = mysqli_real_escape_string($connect, $_POST['dropdownsid']);
$objid = mysqli_real_escape_string($connect, $_POST["dropdownobjid"]);
$today = date("Y-m-d H:i:s");

$sql = "INSERT INTO View_Bookings (sid, objid, dateRetreived) VALUES ('$sid', '$objid', '$today');";
if ($connect->query($sql) === TRUE) {
    echo "$sql \n";
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $connect->error;
}
?>