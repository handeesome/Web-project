<?php
include "config.php";
$sid =  $_POST["sid"];
$shift = mysqli_real_escape_string($connect, $_POST["shift"]);
$collegename = mysqli_real_escape_string($connect, $_POST["college"]);

$sql_sid = "SELECT username FROM Student WHERE sid='$sid';";

if ($result = $connect -> query($sql_sid)) {
  
    $sql_admin = "INSERT INTO CollegeAdmin (sid, shift) values ('$sid', '$shift');";
    if ($connect->query($sql_admin) === TRUE) {
      echo "$sql_admin"." <br>";
      echo "New record created successfully <br>";
  } else {
    echo "Error: " . $sql_admin . "<br>" . $connect->error;
  }
    $offid_query = "SELECT offid FROM CollegeOffice WHERE name = '$collegename';";
    $offid = mysqli_query($connect, $offid_query);
    $row = mysqli_fetch_array($offid);
    $offid = $row['offid'];
    $today = date("Y-m-d");
    echo $today;
    $sql_worksin = "INSERT INTO WorksIn (sid, offid, since) value ('$sid','$offid', '$today');";
    if ($connect->query($sql_worksin) === TRUE) {
        echo "$sql_worksin"." <br>";
        echo "New record created successfully";
    } else {
      echo "Error: " . $sql_worksin . "<br>" . $connect->error;
    }
}
else{
   echo "SID does not exist";
}
